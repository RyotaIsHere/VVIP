import UserAgent from './user-agent';


export default UserAgent;
