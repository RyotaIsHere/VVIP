*the pull request description goes here...*


**Please check the boxes below to confirm that you have completed these steps:**

* [ ] I have read and followed the [Contribution Agreement](https://github.com/intoli/user-agents/blob/master/CONTRIBUTING.md).
* [ ] I have signed the project [Contributor License Agreement](https://github.com/intoli/user-agents/blob/master/CONTRIBUTING.md).
