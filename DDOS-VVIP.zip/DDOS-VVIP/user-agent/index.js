
module.exports = require('./lib/user-agent');