
1.0.4 / 2011-05-04 
==================

  * Added Googlebot user-agent [straps]
  * Added curl and epiphany parser [straps]
  * Added iPhone support [straps]

1.0.3 / 2011-04-06 
==================

  * Added curl and epiphany parser [straps]
  * Added iPhone support [straps]

1.0.1 / 2011-02-02 
==================

  * refactored

0.0.1 / 2010-05-04
==================

  * Initial release
